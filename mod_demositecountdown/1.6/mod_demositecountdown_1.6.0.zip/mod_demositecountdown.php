<?php

 # copyright Copyright (C) 2011 www.waltercedric.com. All Rights Reserved.
 # @license - http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 
// no direct access
defined('_JEXEC') or die('Restricted access');

$text = $params->get('text', '');
$width = (int)$params->get('width');
$height = (int)$params->get('height');
$wmode = (int)$params->get('wmode');
$moduleclass_sfx = (int)$params->get('moduleclass_sfx');

global $mainframe;
$mainframe->addCustomHeadTag('<script type="text/javascript" src="http'.(!empty($_SERVER['HTTPS']) ? 's' : '').'://ajax.googleapis.com/ajax/libs/swfobject/2.2/swfobject.js"></script>');

$lastRenewed = date ("d F Y H:i:s.", filemtime(dirname(__FILE__).DS."index.html"));

echo '<div class="module '.$moduleclass_sfx.'">';
echo ' <div class="text">'.$text.'</div>';
echo ' <div id="flashxmlcountdown"></div>
       <script type="text/javascript">'."swfobject.embedSWF('modules/mod_demositecountdown/CountdownFX.swf', 'flashxmlcountdown', '{$width}', '{$height}', '9.0.0.0', '', { folderPath: 'modules/mod_demositecountdown/' }, { scale: 'noscale', salign: 'tl', wmode: '{$wmode}', allowScriptAccess: 'sameDomain', allowFullScreen: true }, {});</script>";
echo ' <div class="lastTime">Last time:'.$lastRenewed.'</div>';
echo '</div>';